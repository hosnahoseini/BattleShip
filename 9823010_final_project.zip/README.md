# C_project_FALL2020
final project c ( battles ships)
Fundamentals of programming final project In C Summary :

Battleship (also Battleships or Sea Battle) is a strategy type guessing game for two players (or player with bot).

In this game first you and your opponent first put your ship on game board, and then you have to guess the place of opponent ship and shoot them.(each successful shoot adds some point to you).
The player who destroy all the opponent ships first will win the game.

In this project there are some more feature like adjusting number and len of ships and size of board game, save and load other games, use rocket, see play back.

Hope you enjoy it:)
